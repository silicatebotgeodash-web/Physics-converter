package com.physicsconverter.item;

import com.physicsconverter.entity.PhysicsBlockEntity;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Item hasil konversi. Kalau diletakkan, muncul block berfisika. */
public class PhysicsBlockItem extends Item {
	public PhysicsBlockItem(Settings settings) {
		super(settings);
	}

	/** Block apa saja yang bisa dimasukkan ke Physics Converter. */
	public static boolean isConvertible(ItemStack stack) {
		if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
			return false;
		}
		Block block = blockItem.getBlock();
		BlockState state = block.getDefaultState();
		return !state.isAir()
			&& state.getRenderType() == BlockRenderType.MODEL
			&& !(block instanceof BlockEntityProvider);
	}

	public static ItemStack of(Block block, int count) {
		ItemStack stack = new ItemStack(ModItems.PHYSICS_BLOCK, count);
		NbtCompound nbt = new NbtCompound();
		nbt.putString("block", Registries.BLOCK.getId(block).toString());
		stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
		return stack;
	}

	public static Block getBlock(ItemStack stack) {
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		if (data == null) {
			return Blocks.STONE;
		}
		Identifier id = Identifier.tryParse(data.copyNbt().getString("block"));
		if (id == null) {
			return Blocks.STONE;
		}
		Block block = Registries.BLOCK.get(id);
		return block == Blocks.AIR ? Blocks.STONE : block;
	}

	@Override
	public Text getName(ItemStack stack) {
		return Text.translatable("item.physicsconverter.physics_block.named", getBlock(stack).getName());
	}

	@Override
	public boolean hasGlint(ItemStack stack) {
		return true;
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext context) {
		World world = context.getWorld();
		if (world.isClient) {
			return ActionResult.SUCCESS;
		}

		Block block = getBlock(context.getStack());
		BlockPos pos = context.getBlockPos().offset(context.getSide());

		PhysicsBlockEntity entity = new PhysicsBlockEntity(ModEntities.PHYSICS_BLOCK, world);
		entity.setBlockState(block.getDefaultState());
		entity.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0f, 0.0f);
		if (!world.isSpaceEmpty(entity)) {
			return ActionResult.FAIL;
		}

		world.spawnEntity(entity);
		world.playSound(null, pos, block.getDefaultState().getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);

		PlayerEntity player = context.getPlayer();
		if (player == null || !player.isCreative()) {
			context.getStack().decrement(1);
		}
		return ActionResult.SUCCESS;
	}
}
