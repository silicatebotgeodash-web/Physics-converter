package com.physicsconverter;

import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.network.PushPayload;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModItems;
import com.physicsconverter.registry.ModScreenHandlers;
import com.physicsconverter.world.PhysicsBlocksState;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

public class PhysicsConverterMod implements ModInitializer {
	public static final String MOD_ID = "physicsconverter";

	@Override
	public void onInitialize() {
		ModEntities.init();
		ModItems.init();
		ModScreenHandlers.init();

		// Dorongan dari pemain yang berjalan menabrak blok fisika (dikirim client)
		PayloadTypeRegistry.playC2S().register(PushPayload.ID, PushPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(PushPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> PhysicsBlocks.pushFromPlayer(player, payload.dir()));
		});

		// Kestabilan struktur: blok yang menjulur terlalu jauh / kehilangan penyangga jatuh
		ServerTickEvents.END_WORLD_TICK.register(world -> {
			if (world.getTime() % 4 == 0) {
				PhysicsBlocksState.get(world).tick(world);
			}
		});

		UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
			if (world.isClient || player.isSpectator()) {
				return ActionResult.PASS;
			}
			ServerWorld serverWorld = (ServerWorld) world;
			ItemStack stack = player.getStackInHand(hand);

			// Item blok fisik: diletakkan sebagai block ASLI (solid), posisinya dicatat sebagai blok fisika
			if (PhysicsBlocks.isPhysics(stack)) {
				Block expected = PhysicsBlocks.getBlock(stack);
				ItemUsageContext usage = new ItemUsageContext(player, hand, hit);
				BlockPos placePos = new ItemPlacementContext(usage).getBlockPos();
				ActionResult result = stack.useOnBlock(usage);
				if (result.isAccepted() && serverWorld.getBlockState(placePos).getBlock() == expected) {
					PhysicsBlocksState.get(serverWorld).add(placePos, expected);
				}
				return result;
			}

			// Tangan kosong klik kanan blok fisika = dorong
			if (hand == Hand.MAIN_HAND && stack.isEmpty()) {
				BlockPos pos = hit.getBlockPos();
				if (PhysicsBlocksState.get(serverWorld).contains(pos)) {
					PhysicsBlocks.shoveBlock(serverWorld, pos, player);
					return ActionResult.SUCCESS;
				}
			}
			return ActionResult.PASS;
		});

		// Klik kiri blok fisika = langsung hancur
		AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
			if (world.isClient || player.isSpectator() || hand != Hand.MAIN_HAND) {
				return ActionResult.PASS;
			}
			ServerWorld serverWorld = (ServerWorld) world;
			PhysicsBlocksState state = PhysicsBlocksState.get(serverWorld);
			if (!state.contains(pos)) {
				return ActionResult.PASS;
			}
			state.remove(pos);
			serverWorld.breakBlock(pos, !player.isCreative(), player);
			return ActionResult.SUCCESS;
		});
	}
}
