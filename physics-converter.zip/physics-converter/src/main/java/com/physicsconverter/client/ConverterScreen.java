package com.physicsconverter.client;

import com.physicsconverter.entity.PhysicsMass;
import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.screen.ConverterScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;

public class ConverterScreen extends HandledScreen<ConverterScreenHandler> {
	private static final int PURPLE = 0xFF8A2BE2;
	private static final int GREEN = 0xFF3CC13C;
	private static final int ARROW = 0xFF555555;

	public ConverterScreen(ConverterScreenHandler handler, PlayerInventory inventory, Text title) {
		super(handler, inventory, title);
		this.backgroundWidth = 176;
		this.backgroundHeight = 166;
		this.playerInventoryTitleY = this.backgroundHeight - 94;
	}

	private void frame(DrawContext context, int x, int y, int color) {
		context.fill(x - 3, y - 3, x + 19, y - 2, color);
		context.fill(x - 3, y + 18, x + 19, y + 19, color);
		context.fill(x - 3, y - 3, x - 2, y + 19, color);
		context.fill(x + 18, y - 3, x + 19, y + 19, color);
	}

	@Override
	protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
		int left = this.x;
		int top = this.y;

		// Panel abu-abu ala GUI vanilla (digambar dengan kotak, tanpa file tekstur)
		context.fill(left, top, left + this.backgroundWidth, top + this.backgroundHeight, 0xFF000000);
		context.fill(left + 1, top + 1, left + this.backgroundWidth - 1, top + this.backgroundHeight - 1, 0xFFC6C6C6);
		context.fill(left + 1, top + 1, left + this.backgroundWidth - 2, top + 2, 0xFFFFFFFF);
		context.fill(left + 1, top + 1, left + 2, top + this.backgroundHeight - 2, 0xFFFFFFFF);

		for (Slot slot : this.handler.slots) {
			int sx = left + slot.x;
			int sy = top + slot.y;
			context.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
			context.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
		}

		// Slot input (ungu) -> panah -> slot hasil (hijau)
		frame(context, left + 50, top + 35, PURPLE);
		frame(context, left + 110, top + 35, GREEN);

		int ax = left + 74;
		int ay = top + 39;
		context.fill(ax, ay + 3, ax + 14, ay + 7, ARROW);
		context.fill(ax + 14, ay, ax + 16, ay + 10, ARROW);
		context.fill(ax + 16, ay + 1, ax + 18, ay + 9, ARROW);
		context.fill(ax + 18, ay + 2, ax + 20, ay + 8, ARROW);
		context.fill(ax + 20, ay + 3, ax + 22, ay + 7, ARROW);
	}

	@Override
	protected void drawForeground(DrawContext context, int mouseX, int mouseY) {
		super.drawForeground(context, mouseX, mouseY);
		ItemStack out = this.handler.getOutputStack();
		if (PhysicsBlocks.isPhysics(out)) {
			double mass = PhysicsMass.of(PhysicsBlocks.getBlock(out).getDefaultState());
			Text text = Text.translatable("gui.physicsconverter.weight", PhysicsMass.format(mass));
			int w = this.textRenderer.getWidth(text);
			context.drawText(this.textRenderer, text, (this.backgroundWidth - w) / 2, 58, 0x404040, false);
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.drawMouseoverTooltip(context, mouseX, mouseY);
	}
}
