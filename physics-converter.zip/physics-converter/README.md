# Physics Converter (Fabric 1.21.1)

## Cara pakai di game
1. Dapatkan item **Physics Converter** (creative tab *Tools*, atau `/give @s physicsconverter:physics_converter`).
   Resep survival: besi di sudut, redstone di sisi, ender pearl di tengah.
2. Pegang item, klik kanan -> muncul UI 1 slot.
3. Masukkan block apa pun -> langsung berubah jadi **Physics Block** (jumlah ikut). Ambil dari slot.
4. Letakkan Physics Block seperti block biasa -> jadi block berfisika.

## Kontrol block berfisika
- Jalan menabrak = didorong
- Klik kiri = ditendang ke arah pandangan
- Sneak + klik kiri = dihancurkan (drop block biasa)
- Ditumpuk lalu bagian bawah dihancurkan = yang di atas jatuh / terpisah
- Block yang meluncur menabrak block fisika lain = mendorongnya (domino)

## Build dari HP (GitHub Actions)
1. Buat repo baru di GitHub.
2. Upload `physics-converter.zip` ke root repo (jangan diekstrak).
3. Buat file `.github/workflows/build.yml` lewat "Create new file", isi dengan isi `build.yml`.
4. Tab Actions -> tunggu build selesai -> download artifact `physics-converter-mod` -> ambil file .jar-nya.
5. Taruh .jar di folder mods bersama Fabric API 1.21.1.

Butuh: Fabric Loader 0.16+, Fabric API, Java 21.
