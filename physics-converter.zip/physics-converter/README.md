# Physics Converter (Fabric 1.21.1)

## Cara pakai di game
1. Dapatkan item **Physics Converter** (creative tab *Tools*, atau `/give @s physicsconverter:physics_converter`).
   Resep survival: besi di sudut, redstone di sisi, ender pearl di tengah.
2. Pegang item, klik kanan -> muncul UI 2 slot.
   - Slot kiri (ungu) = masukkan block apa pun.
   - Slot kanan (hijau) = hasil **Physics Block** (jumlah ikut). Ambil hasilnya, block di slot kiri terpakai.
   - Tulisan "Berat" di UI menunjukkan berat block tersebut.
3. Physics Block punya icon/tekstur sama persis dengan block aslinya (bedanya cuma berkilau + tulisan "Berat" di tooltip).

## Menaruh & menumpuk
- Klik kanan ke block biasa -> blok fisika muncul.
- Bidik blok fisika lain lalu klik kanan dengan Physics Block -> ditaruh di sisi yang kamu bidik (atas = menumpuk).

## Kontrol blok fisika
- Klik kiri = hancur (drop block biasa)
- Klik kanan dengan tangan kosong / item biasa = dorong ke arah pandangan + muncul tulisan berat di action bar
- Blok yang meluncur menabrak blok lain = mendorongnya (domino); dihitung pakai berat kedua blok
- Penyangga dihancurkan = blok di atasnya jatuh / terpisah

## Berat
- Berat dihitung dari kekerasan block; block padat (netherite, emas, besi, obsidian, dll) punya berat khusus.
- Netherite 14.0, emas 11.0, besi 9.0, batu ~1.9, tanah ~1.3, wol ~1.5, TNT/kaca/daun ringan.
- Berat besar = susah didorong, jatuh lebih cepat, menghantam lebih keras, melukai makhluk di bawahnya,
  dan meremukkan blok yang lebih ringan di bawahnya (jatuhkan netherite ke tumpukan tanah/batu).
- Blok ringan menabrak blok berat = memantul balik.

## Build dari HP (GitHub Actions)
1. Buat repo baru di GitHub.
2. Upload `physics-converter.zip` ke root repo (jangan diekstrak).
3. Buat file `.github/workflows/build.yml` lewat "Create new file", isi dengan isi `build.yml`.
4. Tab Actions -> tunggu build selesai -> download artifact `physics-converter-mod` -> ambil file .jar-nya.
5. Taruh .jar di folder mods bersama Fabric API 1.21.1.

Butuh: Fabric Loader 0.16+, Fabric API, Java 21.
