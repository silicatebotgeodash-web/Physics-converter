package com.physicsconverter;

import com.physicsconverter.client.ConverterScreen;
import com.physicsconverter.client.PhysicsBlockRenderer;
import com.physicsconverter.network.PushPayload;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.network.ClientPlayerEntity;

public class PhysicsConverterClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(ModEntities.PHYSICS_BLOCK, PhysicsBlockRenderer::new);
		HandledScreens.register(ModScreenHandlers.CONVERTER, ConverterScreen::new);

		// Pemain menekan tombol jalan sambil tertahan sesuatu -> kasih tahu server arahnya, server mendorong blok fisika di depan
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ClientPlayerEntity player = client.player;
			if (player == null || client.currentScreen != null || player.isSpectator()) {
				return;
			}
			if (!player.horizontalCollision || !ClientPlayNetworking.canSend(PushPayload.ID)) {
				return;
			}
			float forward = player.input.movementForward;
			float side = player.input.movementSideways;
			if (forward == 0.0f && side == 0.0f) {
				return;
			}

			double yaw = Math.toRadians(player.getYaw());
			double sin = Math.sin(yaw);
			double cos = Math.cos(yaw);
			double dx = side * cos - forward * sin;
			double dz = forward * cos + side * sin;

			int dir;
			if (Math.abs(dx) > Math.abs(dz)) {
				dir = dx > 0 ? 0 : 1;
			} else {
				dir = dz > 0 ? 2 : 3;
			}
			ClientPlayNetworking.send(new PushPayload(dir));
		});
	}
}
