package com.physicsconverter;

import com.physicsconverter.client.ConverterScreen;
import com.physicsconverter.client.PhysicsBlockRenderer;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public class PhysicsConverterClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(ModEntities.PHYSICS_BLOCK, PhysicsBlockRenderer::new);
		HandledScreens.register(ModScreenHandlers.CONVERTER, ConverterScreen::new);
	}
}
