# Physics Converter (Fabric 1.21.1)

## Cara pakai di game
1. Dapatkan item **Physics Converter** (creative tab *Tools*, atau `/give @s physicsconverter:physics_converter`).
   Resep survival: besi di sudut, redstone di sisi, ender pearl di tengah.
2. Pegang item, klik kanan -> UI 2 slot.
   - Slot kiri (ungu) = masukkan block apa pun.
   - Slot kanan (hijau) = hasil **Physics Block**. Ambil hasilnya, block di slot kiri terpakai.
3. Physics Block = item block asli (icon sama persis, tanpa efek enchant), bedanya ada tulisan "Berat" di tooltip.

## Blok fisika = block solid asli
- Physics Block yang diletakkan menjadi block SOLID biasa (bukan entity). Dunia mengingat posisi mana yang berfisika.
- **Menyatu**: blok yang ditumpuk / berdempetan satu sama lain menjadi satu struktur.
- **Penyangga**: blok yang menjulur lebih dari 3 blok dari penyangga (tanah / block biasa) akan jatuh. Menara lurus ke atas tidak apa-apa.
  Menempel di dinding block biasa menghitung sebagai penyangga (jangkauan 2).
  Angka 3 bisa diubah di `PhysicsBlocksState.MAX_REACH`.
- Penyangga dihancurkan = blok yang kehilangan penyangga jatuh dan memisah.
- Blok yang jatuh sementara jadi entity, lalu memadat jadi block solid lagi begitu diam.

## Mendorong
- **Jalan menabrak blok** = blok didorong (blok berat merayap pelan, blok ringan ikut kecepatan jalan).
- Klik kanan tangan kosong = dorong sekali ke arah pandangan + muncul tulisan berat.
- Blok yang meluncur menabrak blok lain = mendorongnya (domino), dihitung pakai berat kedua blok.
- Klik kiri = blok langsung hancur (drop block biasa).

## Berat
- Berat dihitung dari kekerasan block; block padat (netherite, emas, besi, obsidian, dll) punya berat khusus.
- Netherite 14.0, emas 11.0, besi 9.0, batu ~1.9, tanah ~1.3, wol ~1.5, TNT/kaca/daun ringan.
- Berat besar = susah didorong, jatuh lebih cepat, menghantam lebih keras, melukai makhluk di bawahnya,
  dan meremukkan blok yang lebih ringan di bawahnya.

## Build dari HP (GitHub Actions)
1. Buat repo baru di GitHub.
2. Upload `physics-converter.zip` ke root repo (jangan diekstrak).
3. Buat file `.github/workflows/build.yml` lewat "Create new file", isi dengan isi `build.yml`.
4. Tab Actions -> tunggu build selesai -> download artifact `physics-converter-mod` -> ambil file .jar-nya.
5. Taruh .jar di folder mods bersama Fabric API 1.21.1.

Butuh: Fabric Loader 0.16+, Fabric API, Java 21.
