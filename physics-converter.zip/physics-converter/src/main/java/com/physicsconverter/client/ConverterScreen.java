package com.physicsconverter.client;

import com.physicsconverter.screen.ConverterScreenHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;

public class ConverterScreen extends HandledScreen<ConverterScreenHandler> {
	public ConverterScreen(ConverterScreenHandler handler, PlayerInventory inventory, Text title) {
		super(handler, inventory, title);
		this.backgroundWidth = 176;
		this.backgroundHeight = 166;
		this.playerInventoryTitleY = this.backgroundHeight - 94;
	}

	@Override
	protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
		int left = this.x;
		int top = this.y;

		// Panel abu-abu ala GUI vanilla (digambar dengan kotak, tanpa file tekstur)
		context.fill(left, top, left + this.backgroundWidth, top + this.backgroundHeight, 0xFF000000);
		context.fill(left + 1, top + 1, left + this.backgroundWidth - 1, top + this.backgroundHeight - 1, 0xFFC6C6C6);
		context.fill(left + 1, top + 1, left + this.backgroundWidth - 2, top + 2, 0xFFFFFFFF);
		context.fill(left + 1, top + 1, left + 2, top + this.backgroundHeight - 2, 0xFFFFFFFF);

		for (Slot slot : this.handler.slots) {
			int sx = left + slot.x;
			int sy = top + slot.y;
			context.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
			context.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
		}

		// Slot converter dikasih bingkai ungu biar kelihatan beda
		int cx = left + 80;
		int cy = top + 35;
		context.fill(cx - 3, cy - 3, cx + 19, cy - 2, 0xFF8A2BE2);
		context.fill(cx - 3, cy + 18, cx + 19, cy + 19, 0xFF8A2BE2);
		context.fill(cx - 3, cy - 3, cx - 2, cy + 19, 0xFF8A2BE2);
		context.fill(cx + 18, cy - 3, cx + 19, cy + 19, 0xFF8A2BE2);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		this.drawMouseoverTooltip(context, mouseX, mouseY);
	}
}
