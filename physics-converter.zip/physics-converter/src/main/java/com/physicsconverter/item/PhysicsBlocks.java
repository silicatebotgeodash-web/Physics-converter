package com.physicsconverter.item;

import java.util.List;

import com.physicsconverter.entity.PhysicsBlockEntity;
import com.physicsconverter.entity.PhysicsMass;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.world.PhysicsBlocksState;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Helper untuk blok fisika.
 *
 * Item blok fisik = item block ASLI yang diberi tanda (icon/tekstur otomatis sama, tanpa efek enchant).
 * Kalau diletakkan jadi block ASLI yang solid; posisinya dicatat di {@link PhysicsBlocksState}.
 * Blok baru "bangun" jadi entity saat jatuh / didorong, lalu jadi block solid lagi saat diam.
 */
public final class PhysicsBlocks {
	private static final String KEY = "physicsconverter_physics";
	private static final double SHOVE_IMPULSE = 0.6;

	private PhysicsBlocks() {
	}

	public static boolean isPhysics(ItemStack stack) {
		if (stack.isEmpty()) {
			return false;
		}
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		return data != null && data.copyNbt().getBoolean(KEY);
	}

	/** Block apa saja yang bisa dimasukkan ke Physics Converter. */
	public static boolean isConvertible(ItemStack stack) {
		if (stack.isEmpty() || isPhysics(stack) || !(stack.getItem() instanceof BlockItem blockItem)) {
			return false;
		}
		Block block = blockItem.getBlock();
		BlockState state = block.getDefaultState();
		return !state.isAir()
			&& state.getRenderType() == BlockRenderType.MODEL
			&& !(block instanceof BlockEntityProvider);
	}

	public static Block getBlock(ItemStack stack) {
		return stack.getItem() instanceof BlockItem blockItem ? blockItem.getBlock() : Blocks.STONE;
	}

	/** Berat blok (lihat {@link PhysicsMass}). */
	public static double massOf(Block block) {
		return PhysicsMass.of(block.getDefaultState());
	}

	/** Ubah stack blok biasa jadi stack blok fisik (jumlah tetap, icon tetap sama, tanpa efek enchant). */
	public static ItemStack convert(ItemStack source) {
		ItemStack out = source.copy();
		Block block = getBlock(source);

		NbtComponent existing = out.get(DataComponentTypes.CUSTOM_DATA);
		NbtCompound tag = existing == null ? new NbtCompound() : existing.copyNbt();
		tag.putBoolean(KEY, true);
		out.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));

		out.set(DataComponentTypes.ITEM_NAME, Text.translatable("item.physicsconverter.physics_block.named", block.getName()));
		out.set(DataComponentTypes.LORE, new LoreComponent(List.<Text>of(
			Text.translatable("tooltip.physicsconverter.weight", PhysicsMass.format(massOf(block))).formatted(Formatting.GRAY)
		)));
		return out;
	}

	/**
	 * Bangunkan blok fisika di pos: block solid dihapus lalu jadi entity yang bergerak.
	 * Mengembalikan null kalau pos itu bukan blok fisika.
	 */
	public static PhysicsBlockEntity wake(ServerWorld world, BlockPos pos, double vx, double vz) {
		PhysicsBlocksState state = PhysicsBlocksState.get(world);
		if (!state.contains(pos)) {
			return null;
		}
		BlockState blockState = world.getBlockState(pos);
		state.remove(pos);
		if (blockState.isAir()) {
			return null;
		}
		world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);

		PhysicsBlockEntity entity = new PhysicsBlockEntity(ModEntities.PHYSICS_BLOCK, world);
		entity.setBlockState(blockState);
		entity.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0f, 0.0f);
		entity.setVelocity(vx, 0.0, vz);
		world.spawnEntity(entity);
		return entity;
	}

	/** Klik kanan tangan kosong ke blok fisika: dorong ke arah pandangan. */
	public static void shoveBlock(ServerWorld world, BlockPos pos, PlayerEntity player) {
		Block block = PhysicsBlocksState.get(world).get(pos);
		if (block == null) {
			return;
		}
		double mass = massOf(block);

		Vec3d look = player.getRotationVec(1.0f);
		double lx = look.x;
		double lz = look.z;
		if (Math.abs(lx) < 1.0E-3 && Math.abs(lz) < 1.0E-3) {
			lx = pos.getX() + 0.5 - player.getX();
			lz = pos.getZ() + 0.5 - player.getZ();
		}
		int ax = 0;
		int az = 0;
		if (Math.abs(lx) > Math.abs(lz)) {
			ax = lx > 0 ? 1 : -1;
		} else {
			az = lz > 0 ? 1 : -1;
		}

		double impulse = SHOVE_IMPULSE / mass;
		BlockState state = world.getBlockState(pos);
		wake(world, pos, ax * impulse, az * impulse);
		world.playSound(null, pos, state.getSoundGroup().getHitSound(), SoundCategory.BLOCKS, 0.8f, 0.9f);
		player.sendMessage(Text.translatable("message.physicsconverter.weight", block.getName(), PhysicsMass.format(mass)), true);
	}

	/**
	 * Pemain berjalan menabrak blok (arah dikirim client): blok/entity di depan didorong.
	 * dirIdx: 0 = +X, 1 = -X, 2 = +Z, 3 = -Z.
	 */
	public static void pushFromPlayer(ServerPlayerEntity player, int dirIdx) {
		if (player.isSpectator() || dirIdx < 0 || dirIdx > 3) {
			return;
		}
		int ax = dirIdx == 0 ? 1 : (dirIdx == 1 ? -1 : 0);
		int az = dirIdx == 2 ? 1 : (dirIdx == 3 ? -1 : 0);
		ServerWorld world = player.getServerWorld();

		// 1. Blok fisika yang sedang bergerak (entity) di depan pemain
		Box probe = player.getBoundingBox().expand(0.2, 0.0, 0.2).offset(ax * 0.35, 0.0, az * 0.35);
		boolean pushed = false;
		for (PhysicsBlockEntity e : world.getEntitiesByClass(PhysicsBlockEntity.class, probe, PhysicsBlockEntity::isAlive)) {
			if ((e.getX() - player.getX()) * ax + (e.getZ() - player.getZ()) * az > 0.0) {
				e.pushed(ax, az);
				pushed = true;
			}
		}
		if (pushed) {
			return;
		}

		// 2. Blok solid di depan (setinggi kaki atau setinggi kepala)
		PhysicsBlocksState state = PhysicsBlocksState.get(world);
		for (double dy : new double[] {0.1, 1.1}) {
			BlockPos p = BlockPos.ofFloored(player.getX() + ax * 0.45, player.getY() + dy, player.getZ() + az * 0.45);
			Block block = state.get(p);
			if (block == null) {
				continue;
			}
			double speed = PhysicsMass.pushSpeed(massOf(block));
			wake(world, p, ax * speed, az * speed);
			return;
		}
	}
}
