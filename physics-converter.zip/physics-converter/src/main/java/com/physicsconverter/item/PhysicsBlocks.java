package com.physicsconverter.item;

import java.util.List;

import com.physicsconverter.entity.PhysicsBlockEntity;
import com.physicsconverter.entity.PhysicsMass;
import com.physicsconverter.registry.ModEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Helper untuk "item blok fisik". Item blok fisik adalah item blok ASLI yang diberi tanda,
 * jadi icon / texture-nya otomatis sama persis dengan blok aslinya.
 */
public final class PhysicsBlocks {
	private static final String KEY = "physicsconverter_physics";

	private PhysicsBlocks() {
	}

	public static boolean isPhysics(ItemStack stack) {
		if (stack.isEmpty()) {
			return false;
		}
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		return data != null && data.copyNbt().getBoolean(KEY);
	}

	/** Block apa saja yang bisa dimasukkan ke Physics Converter. */
	public static boolean isConvertible(ItemStack stack) {
		if (stack.isEmpty() || isPhysics(stack) || !(stack.getItem() instanceof BlockItem blockItem)) {
			return false;
		}
		Block block = blockItem.getBlock();
		BlockState state = block.getDefaultState();
		return !state.isAir()
			&& state.getRenderType() == BlockRenderType.MODEL
			&& !(block instanceof BlockEntityProvider);
	}

	public static Block getBlock(ItemStack stack) {
		return stack.getItem() instanceof BlockItem blockItem ? blockItem.getBlock() : Blocks.STONE;
	}

	/** Berat blok (lihat {@link PhysicsMass}). */
	public static double massOf(Block block) {
		return PhysicsMass.of(block.getDefaultState());
	}

	/** Ubah stack blok biasa jadi stack blok fisik (jumlah tetap, icon tetap sama). */
	public static ItemStack convert(ItemStack source) {
		ItemStack out = source.copy();
		Block block = getBlock(source);

		NbtComponent existing = out.get(DataComponentTypes.CUSTOM_DATA);
		NbtCompound tag = existing == null ? new NbtCompound() : existing.copyNbt();
		tag.putBoolean(KEY, true);
		out.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));

		out.set(DataComponentTypes.ITEM_NAME, Text.translatable("item.physicsconverter.physics_block.named", block.getName()));
		out.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
		out.set(DataComponentTypes.LORE, new LoreComponent(List.<Text>of(
			Text.translatable("tooltip.physicsconverter.weight", PhysicsMass.format(massOf(block))).formatted(Formatting.GRAY)
		)));
		return out;
	}

	/** Cek ruang kosong (blok dunia + blok fisik lain). Blok yang cuma menempel tidak dianggap menghalangi. */
	public static boolean canPlace(World world, PhysicsBlockEntity entity) {
		Box box = entity.getBoundingBox();
		for (VoxelShape shape : world.getBlockCollisions(entity, box)) {
			if (!shape.isEmpty()) {
				return false;
			}
		}
		return world.getEntitiesByClass(PhysicsBlockEntity.class, box.contract(0.02), e -> true).isEmpty();
	}

	public static boolean spawn(World world, Block block, double x, double y, double z) {
		PhysicsBlockEntity entity = new PhysicsBlockEntity(ModEntities.PHYSICS_BLOCK, world);
		entity.setBlockState(block.getDefaultState());
		entity.refreshPositionAndAngles(x, y, z, 0.0f, 0.0f);
		if (!canPlace(world, entity)) {
			return false;
		}
		return world.spawnEntity(entity);
	}

	/**
	 * Menumpuk: letakkan blok fisik di atas / samping / bawah blok fisik yang sedang dibidik.
	 * Dipanggil dari UseItemCallback (crosshair mengarah ke entity, bukan ke block biasa).
	 * Mengembalikan pass kalau yang dibidik bukan blok fisik.
	 */
	public static TypedActionResult<ItemStack> placeOnPhysicsBlock(World world, PlayerEntity player, ItemStack stack) {
		double reach = Math.max(player.getEntityInteractionRange(), 3.0);
		Vec3d start = player.getEyePos();
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d end = start.add(look.multiply(reach));
		Box area = player.getBoundingBox().stretch(look.multiply(reach)).expand(1.0);

		EntityHitResult hit = ProjectileUtil.raycast(player, start, end, area,
			e -> e instanceof PhysicsBlockEntity && !e.isSpectator(), reach * reach);
		if (hit == null || !(hit.getEntity() instanceof PhysicsBlockEntity target)) {
			return TypedActionResult.pass(stack);
		}

		// Kalau ada block biasa yang lebih dekat dari blok fisik, biarkan UseBlockCallback yang bekerja
		BlockHitResult blockHit = world.raycast(new RaycastContext(start, end,
			RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player));
		if (blockHit.getType() == HitResult.Type.BLOCK
			&& blockHit.getPos().squaredDistanceTo(start) < hit.getPos().squaredDistanceTo(start)) {
			return TypedActionResult.pass(stack);
		}

		// Di client cukup bilang "berhasil" supaya paket dikirim ke server; server yang menaruh blok
		if (world.isClient) {
			return TypedActionResult.success(stack, true);
		}

		// Sisi blok yang diklik = sisi terdekat dari titik kena
		Box b = target.getBoundingBox();
		Vec3d p = hit.getPos();
		Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
		double[] dist = {
			Math.abs(p.y - b.maxY), Math.abs(p.y - b.minY),
			Math.abs(p.z - b.minZ), Math.abs(p.z - b.maxZ),
			Math.abs(p.x - b.minX), Math.abs(p.x - b.maxX)
		};
		Direction face = Direction.UP;
		double best = Double.MAX_VALUE;
		for (int i = 0; i < dirs.length; i++) {
			if (dist[i] < best) {
				best = dist[i];
				face = dirs[i];
			}
		}

		double size = PhysicsBlockEntity.SIZE;
		double gap = 0.002;
		double x = target.getX() + face.getOffsetX() * (size + gap);
		double z = target.getZ() + face.getOffsetZ() * (size + gap);
		double y;
		if (face == Direction.UP) {
			y = b.maxY + gap;
		} else if (face == Direction.DOWN) {
			y = b.minY - size - gap;
		} else {
			y = target.getY();
		}

		Block block = getBlock(stack);
		if (!spawn(world, block, x, y, z)) {
			return TypedActionResult.fail(stack);
		}
		world.playSound(null, target.getBlockPos(), block.getDefaultState().getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);
		if (!player.isCreative()) {
			stack.decrement(1);
		}
		return TypedActionResult.success(stack, false);
	}
}
