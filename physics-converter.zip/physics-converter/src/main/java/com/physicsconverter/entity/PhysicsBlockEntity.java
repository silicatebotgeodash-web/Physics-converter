package com.physicsconverter.entity;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.item.PhysicsConverterItem;
import com.physicsconverter.world.PhysicsBlocksState;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Wujud BERGERAK dari blok fisika. Blok fisika yang diam adalah block solid asli di dunia;
 * entity ini hanya ada saat blok jatuh (tidak tertopang) atau sedang didorong. Begitu diam,
 * entity ini memadat lagi jadi block solid (lihat {@link #trySettle()}).
 *
 * - Punya berat ({@link PhysicsMass}): blok berat susah didorong, menghantam lebih keras,
 *   dan meremukkan blok yang lebih ringan di bawahnya.
 * - Menabrak blok fisika lain (solid maupun entity) mendorongnya (domino), dihitung pakai berat kedua blok.
 * - Klik kiri = hancur. Klik kanan (tangan kosong / item biasa) = dorong ke arah pandangan.
 */
public class PhysicsBlockEntity extends Entity {
	public static final float SIZE = 1.0f;

	/** Blok jatuh meremukkan blok di bawahnya kalau tenaga tumbukan > berat blok bawah x angka ini. */
	private static final double CRUSH_FACTOR = 3.0;
	/** 1.0 = tumbukan lenting sempurna, 0.0 = menempel. */
	private static final double RESTITUTION = 0.8;
	private static final double SHOVE_IMPULSE = 0.6;
	/** Berapa tick diam sebelum memadat jadi block solid. */
	private static final int SETTLE_TICKS = 6;
	/** Kalau tempat memadatnya terus terhalang selama ini, blok dihancurkan (drop item) supaya tidak hilang. */
	private static final int GIVE_UP_TICKS = 200;

	private static final TrackedData<BlockState> BLOCK_STATE =
		DataTracker.registerData(PhysicsBlockEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);

	private int restTicks = 0;
	private int blockedTicks = 0;

	private BlockState massState = null;
	private double mass = 1.0;

	public PhysicsBlockEntity(EntityType<? extends PhysicsBlockEntity> type, World world) {
		super(type, world);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(BLOCK_STATE, Blocks.STONE.getDefaultState());
	}

	public BlockState getBlockState() {
		return this.dataTracker.get(BLOCK_STATE);
	}

	public void setBlockState(BlockState state) {
		this.dataTracker.set(BLOCK_STATE, state);
	}

	public double getMass() {
		BlockState state = getBlockState();
		if (state != this.massState) {
			this.massState = state;
			this.mass = PhysicsMass.of(state);
		}
		return this.mass;
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		Identifier id = Identifier.tryParse(nbt.getString("block"));
		Block block = id == null ? Blocks.STONE : Registries.BLOCK.get(id);
		if (block == Blocks.AIR) {
			block = Blocks.STONE;
		}
		setBlockState(block.getDefaultState());
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putString("block", Registries.BLOCK.getId(getBlockState().getBlock()).toString());
	}

	@Override
	public boolean canHit() {
		return !this.isRemoved();
	}

	@Override
	public boolean isCollidable() {
		return true;
	}

	/** Klik kiri pemain = blok hancur. */
	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.getWorld().isClient || this.isRemoved()) {
			return false;
		}
		if (source.getAttacker() instanceof PlayerEntity player) {
			shatter(!player.isCreative());
			return true;
		}
		return false;
	}

	/** Klik kanan: dorong blok. Kalau pegang Physics Block / Physics Converter, biarkan item yang bekerja. */
	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		ItemStack main = player.getStackInHand(Hand.MAIN_HAND);
		if (PhysicsBlocks.isPhysics(main) || main.getItem() instanceof PhysicsConverterItem) {
			return ActionResult.PASS;
		}
		if (hand != Hand.MAIN_HAND) {
			return ActionResult.PASS;
		}
		if (!this.getWorld().isClient) {
			shove(player);
		}
		return ActionResult.success(this.getWorld().isClient);
	}

	private void shove(PlayerEntity player) {
		Vec3d look = player.getRotationVec(1.0f);
		double lx = look.x;
		double lz = look.z;
		if (Math.abs(lx) < 1.0E-3 && Math.abs(lz) < 1.0E-3) {
			lx = this.getX() - player.getX();
			lz = this.getZ() - player.getZ();
		}
		double dx = 0;
		double dz = 0;
		if (Math.abs(lx) > Math.abs(lz)) {
			dx = Math.signum(lx);
		} else {
			dz = Math.signum(lz);
		}

		double m = getMass();
		double impulse = SHOVE_IMPULSE / m;
		this.addVelocity(dx * impulse, 0.0, dz * impulse);
		this.restTicks = 0;

		BlockState state = getBlockState();
		this.getWorld().playSound(null, this.getBlockPos(), state.getSoundGroup().getHitSound(), SoundCategory.BLOCKS, 0.8f, 0.9f);
		player.sendMessage(Text.translatable("message.physicsconverter.weight", state.getBlock().getName(), PhysicsMass.format(m)), true);
	}

	/** Didorong pemain yang berjalan: geser dengan kecepatan sesuai berat (blok berat merayap). */
	public void pushed(double ax, double az) {
		double target = PhysicsMass.pushSpeed(getMass());
		Vec3d v = this.getVelocity();
		double along = v.x * ax + v.z * az;
		if (along < target) {
			this.setVelocity(v.x + ax * (target - along), v.y, v.z + az * (target - along));
		}
		this.restTicks = 0;
	}

	/** Hancurkan blok (efek + drop block asli). */
	public void shatter(boolean drop) {
		if (!(this.getWorld() instanceof ServerWorld serverWorld) || this.isRemoved()) {
			return;
		}
		BlockState state = getBlockState();
		serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(), state.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);
		serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
			this.getX(), this.getY() + 0.5, this.getZ(), 25, 0.3, 0.3, 0.3, 0.05);
		if (drop) {
			this.dropStack(new ItemStack(state.getBlock()));
		}
		this.discard();
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			return;
		}

		double m = getMass();
		boolean water = this.isTouchingWater();

		Vec3d vel = this.getVelocity();
		this.setVelocity(vel.x, vel.y - (water ? 0.012 : 0.04), vel.z);

		Vec3d before = this.getVelocity();
		this.move(MovementType.SELF, before);

		if (this.horizontalCollision) {
			transferMomentum(before);
		}
		if (this.isOnGround() && before.y < -0.25) {
			onImpact(-before.y);
		}

		// Hambatan: blok ringan melayang lebih lambat, blok berat jatuh lebih cepat
		double airDrag = 1.0 - 0.02 / MathHelper.clamp(m, 0.5, 3.0);
		double friction;
		if (water) {
			friction = 0.85;
		} else if (this.isOnGround()) {
			BlockState below = this.getWorld().getBlockState(BlockPos.ofFloored(this.getX(), this.getBoundingBox().minY - 0.5, this.getZ()));
			friction = 0.5 + 0.45 * below.getBlock().getSlipperiness();
		} else {
			friction = 0.98;
		}

		Vec3d v = this.getVelocity();
		v = new Vec3d(v.x * friction, v.y * (water ? 0.85 : airDrag), v.z * friction);
		if (this.isOnGround() && v.horizontalLengthSquared() < 1.0E-5) {
			v = new Vec3d(0, v.y, 0);
		}
		this.setVelocity(v);

		if (this.isOnGround() && v.lengthSquared() < 1.0E-4) {
			this.restTicks++;
		} else {
			this.restTicks = 0;
			this.blockedTicks = 0;
		}

		if (this.restTicks >= SETTLE_TICKS) {
			trySettle();
			if (this.isRemoved()) {
				return;
			}
		}

		// Jatuh ke void
		if (this.getY() < this.getWorld().getBottomY() - 16) {
			this.dropStack(new ItemStack(getBlockState().getBlock()));
			this.discard();
		}
	}

	/** Diam -> jadi block solid lagi di petak terdekat, dan dicatat sebagai blok fisika. */
	private void trySettle() {
		if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
			return;
		}
		BlockPos cell = BlockPos.ofFloored(this.getX(), this.getY() + 0.5, this.getZ());
		BlockState existing = serverWorld.getBlockState(cell);
		boolean free = existing.isAir() || existing.isReplaceable();

		Box cellBox = new Box(cell).contract(0.02);
		boolean blocked = !free
			|| !serverWorld.getEntitiesByClass(LivingEntity.class, cellBox, e -> !e.isSpectator()).isEmpty()
			|| !serverWorld.getEntitiesByClass(PhysicsBlockEntity.class, cellBox, e -> e != this && e.isAlive()).isEmpty();

		if (blocked) {
			// Tunggu (mis. ada pemain / blok lain di petak itu); menyerah kalau terlalu lama
			if (++this.blockedTicks > GIVE_UP_TICKS) {
				shatter(true);
			}
			return;
		}

		BlockState state = getBlockState();
		serverWorld.setBlockState(cell, state);
		PhysicsBlocksState.get(serverWorld).add(cell, state.getBlock());
		this.discard();
	}

	/** Tumbukan saat mendarat: suara/partikel sesuai berat, melukai makhluk, meremukkan blok ringan di bawah. */
	private void onImpact(double speed) {
		double m = getMass();
		double energy = m * speed;
		if (energy < 1.2 || !(this.getWorld() instanceof ServerWorld serverWorld)) {
			return;
		}

		BlockState state = getBlockState();
		float volume = (float) MathHelper.clamp(energy / 5.0, 0.3, 1.6);
		float pitch = (float) MathHelper.clamp(1.3 - m * 0.07, 0.5, 1.2);
		serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(), state.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, volume, pitch);

		int count = (int) MathHelper.clamp(energy * 2.0, 4, 40);
		serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
			this.getX(), this.getY() + 0.05, this.getZ(), count, 0.4, 0.05, 0.4, 0.08);

		// Makhluk yang tertimpa
		List<LivingEntity> victims = serverWorld.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(0.05), LivingEntity::isAlive);
		for (LivingEntity victim : victims) {
			victim.damage(serverWorld.getDamageSources().fallingBlock(this), (float) Math.min(energy * 1.2, 40.0));
		}

		boolean crushed = false;

		// Blok fisika solid di bawah: remuk kalau lebih ringan dari tenaga tumbukan
		PhysicsBlocksState physics = PhysicsBlocksState.get(serverWorld);
		Box box = this.getBoundingBox();
		int y = MathHelper.floor(box.minY - 0.05);
		for (int x = MathHelper.floor(box.minX + 1.0E-3); x <= MathHelper.floor(box.maxX - 1.0E-3); x++) {
			for (int z = MathHelper.floor(box.minZ + 1.0E-3); z <= MathHelper.floor(box.maxZ - 1.0E-3); z++) {
				BlockPos bp = new BlockPos(x, y, z);
				Block below = physics.get(bp);
				if (below != null && energy > PhysicsMass.of(below.getDefaultState()) * CRUSH_FACTOR) {
					physics.remove(bp);
					serverWorld.breakBlock(bp, true, this);
					crushed = true;
				}
			}
		}

		// Blok fisika yang sedang bergerak di bawah
		List<PhysicsBlockEntity> belowEntities = serverWorld.getEntitiesByClass(PhysicsBlockEntity.class,
			box.offset(0, -0.1, 0), e -> e != this && e.isAlive());
		for (PhysicsBlockEntity other : belowEntities) {
			if (energy > other.getMass() * CRUSH_FACTOR) {
				other.shatter(true);
				crushed = true;
			}
		}

		if (crushed) {
			// tembus dengan sisa tenaga
			Vec3d v = this.getVelocity();
			this.setVelocity(v.x, -speed * 0.6, v.z);
			this.setOnGround(false);
			this.restTicks = 0;
		}
	}

	/**
	 * Tumbukan dengan blok fisika lain (domino). Pakai hukum kekekalan momentum dengan kelentingan
	 * RESTITUTION: blok berat menghantam blok ringan -> yang ringan terlempar jauh; blok ringan
	 * menghantam blok berat -> memantul balik. Blok solid yang kena dibangunkan jadi entity bergerak.
	 */
	private void transferMomentum(Vec3d before) {
		double speed = Math.hypot(before.x, before.z);
		if (speed < 0.05 || !(this.getWorld() instanceof ServerWorld serverWorld)) {
			return;
		}
		int sx = 0;
		int sz = 0;
		if (Math.abs(before.x) > Math.abs(before.z)) {
			sx = before.x > 0 ? 1 : -1;
		} else {
			sz = before.z > 0 ? 1 : -1;
		}
		double u1 = before.x * sx + before.z * sz;
		if (u1 <= 0.02) {
			return;
		}

		double m1 = getMass();
		double result = u1; // kecepatan blok ini sepanjang arah gerak setelah semua tumbukan
		boolean hit = false;

		// 1. Blok fisika lain yang sedang bergerak
		Box probe = this.getBoundingBox().expand(0.06, -0.05, 0.06);
		List<PhysicsBlockEntity> others = serverWorld.getEntitiesByClass(PhysicsBlockEntity.class, probe, e -> e != this && e.isAlive());
		for (PhysicsBlockEntity other : others) {
			if ((other.getX() - this.getX()) * sx + (other.getZ() - this.getZ()) * sz < 0.5) {
				continue;
			}
			Vec3d ov = other.getVelocity();
			double u2 = ov.x * sx + ov.z * sz;
			if (u1 <= u2) {
				continue;
			}
			double m2 = other.getMass();
			double total = m1 + m2;
			double v1 = (m1 * u1 + m2 * u2 - m2 * RESTITUTION * (u1 - u2)) / total;
			double v2 = (m1 * u1 + m2 * u2 + m1 * RESTITUTION * (u1 - u2)) / total;
			other.addVelocity(sx * (v2 - u2), 0, sz * (v2 - u2));
			other.restTicks = 0;
			result = Math.min(result, v1);
			hit = true;
		}

		// 2. Blok fisika solid di depan
		PhysicsBlocksState physics = PhysicsBlocksState.get(serverWorld);
		Set<BlockPos> cells = new LinkedHashSet<>();
		double fx = this.getX() + sx * 0.56;
		double fz = this.getZ() + sz * 0.56;
		for (double t : new double[] {-0.4, 0.0, 0.4}) {
			double px = fx + (sz != 0 ? t : 0.0);
			double pz = fz + (sx != 0 ? t : 0.0);
			cells.add(BlockPos.ofFloored(px, this.getY() + 0.5, pz));
		}
		for (BlockPos cp : cells) {
			Block block = physics.get(cp);
			if (block == null) {
				continue;
			}
			double m2 = PhysicsMass.of(block.getDefaultState());
			double total = m1 + m2;
			double v1 = (m1 * u1 - m2 * RESTITUTION * u1) / total;
			double v2 = (m1 * u1 + m1 * RESTITUTION * u1) / total;
			PhysicsBlocks.wake(serverWorld, cp, sx * v2, sz * v2);
			result = Math.min(result, v1);
			hit = true;
		}

		if (hit) {
			Vec3d cur = this.getVelocity();
			double c = cur.x * sx + cur.z * sz;
			this.setVelocity(cur.x + sx * (result - c), cur.y, cur.z + sz * (result - c));
			this.restTicks = 0;
		}
	}
}
