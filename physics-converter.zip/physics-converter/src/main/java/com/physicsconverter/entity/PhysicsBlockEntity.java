package com.physicsconverter.entity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.item.PhysicsConverterItem;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Block berfisika.
 *
 * - Jatuh karena gravitasi, bertabrakan dengan block dunia dan block fisika lain (bisa ditumpuk).
 * - Punya berat (lihat {@link PhysicsMass}): blok berat susah didorong, menghantam lebih keras,
 *   dan bisa meremukkan blok yang lebih ringan di bawahnya.
 * - Klik kiri = hancur. Klik kanan (tangan kosong / item biasa) = dorong ke arah pandangan + tampil berat.
 * - Blok yang meluncur menabrak blok fisika lain mendorongnya (domino), dihitung pakai berat kedua blok.
 * - Kalau penyangga hilang, blok di atasnya otomatis jatuh / terpisah.
 */
public class PhysicsBlockEntity extends Entity {
	/** Ukuran hitbox, sedikit di bawah 1 supaya tumpukan tidak tersangkut / z-fighting. */
	public static final float SIZE = 0.999f;

	/** Blok jatuh meremukkan blok di bawahnya kalau tenaga tumbukan > berat blok bawah x angka ini. */
	private static final double CRUSH_FACTOR = 3.0;
	/** 1.0 = tumbukan lenting sempurna (Newton's cradle), 0.0 = menempel. */
	private static final double RESTITUTION = 0.8;
	/** Kekuatan dorongan klik kanan (dibagi berat blok). */
	private static final double SHOVE_IMPULSE = 0.6;

	private static final TrackedData<BlockState> BLOCK_STATE =
		DataTracker.registerData(PhysicsBlockEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);

	private final Map<UUID, Vec3d> seenPlayers = new HashMap<>();
	private int restTicks = 0;

	private BlockState massState = null;
	private double mass = 1.0;

	public PhysicsBlockEntity(EntityType<? extends PhysicsBlockEntity> type, World world) {
		super(type, world);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(BLOCK_STATE, Blocks.STONE.getDefaultState());
	}

	public BlockState getBlockState() {
		return this.dataTracker.get(BLOCK_STATE);
	}

	public void setBlockState(BlockState state) {
		this.dataTracker.set(BLOCK_STATE, state);
	}

	public double getMass() {
		BlockState state = getBlockState();
		if (state != this.massState) {
			this.massState = state;
			this.mass = PhysicsMass.of(state);
		}
		return this.mass;
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		Identifier id = Identifier.tryParse(nbt.getString("block"));
		Block block = id == null ? Blocks.STONE : Registries.BLOCK.get(id);
		if (block == Blocks.AIR) {
			block = Blocks.STONE;
		}
		setBlockState(block.getDefaultState());
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putString("block", Registries.BLOCK.getId(getBlockState().getBlock()).toString());
	}

	@Override
	public boolean canHit() {
		return !this.isRemoved();
	}

	@Override
	public boolean isCollidable() {
		return true;
	}

	/** Klik kiri pemain = blok hancur. */
	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.getWorld().isClient || this.isRemoved()) {
			return false;
		}
		if (source.getAttacker() instanceof PlayerEntity player) {
			shatter(!player.isCreative());
			return true;
		}
		return false;
	}

	/** Klik kanan: dorong blok. Kalau pegang Physics Block / Physics Converter, biarkan item yang bekerja. */
	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		ItemStack main = player.getStackInHand(Hand.MAIN_HAND);
		if (PhysicsBlocks.isPhysics(main) || main.getItem() instanceof PhysicsConverterItem) {
			return ActionResult.PASS;
		}
		if (hand != Hand.MAIN_HAND) {
			return ActionResult.PASS;
		}
		if (!this.getWorld().isClient) {
			shove(player);
		}
		return ActionResult.success(this.getWorld().isClient);
	}

	private void shove(PlayerEntity player) {
		Vec3d look = player.getRotationVec(1.0f);
		double lx = look.x;
		double lz = look.z;
		if (Math.abs(lx) < 1.0E-3 && Math.abs(lz) < 1.0E-3) {
			lx = this.getX() - player.getX();
			lz = this.getZ() - player.getZ();
		}
		// Dorong lurus sepanjang sumbu X atau Z supaya barisan domino rapi
		double dx = 0;
		double dz = 0;
		if (Math.abs(lx) > Math.abs(lz)) {
			dx = Math.signum(lx);
		} else {
			dz = Math.signum(lz);
		}

		double m = getMass();
		double impulse = SHOVE_IMPULSE / m;
		this.addVelocity(dx * impulse, 0.0, dz * impulse);
		this.restTicks = 0;

		BlockState state = getBlockState();
		this.getWorld().playSound(null, this.getBlockPos(), state.getSoundGroup().getHitSound(), SoundCategory.BLOCKS, 0.8f, 0.9f);
		player.sendMessage(Text.translatable("message.physicsconverter.weight", state.getBlock().getName(), PhysicsMass.format(m)), true);
	}

	/** Hancurkan blok (efek + drop block asli). */
	public void shatter(boolean drop) {
		if (!(this.getWorld() instanceof ServerWorld serverWorld) || this.isRemoved()) {
			return;
		}
		BlockState state = getBlockState();
		serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(), state.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);
		serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
			this.getX(), this.getY() + 0.5, this.getZ(), 25, 0.3, 0.3, 0.3, 0.05);
		if (drop) {
			this.dropStack(new ItemStack(state.getBlock()));
		}
		this.discard();
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			return;
		}

		pushByPlayers();

		// Tidur hemat CPU kalau sudah diam (tetap cek tiap 4 tick kalau penyangga hilang)
		boolean asleep = this.restTicks > 10 && this.getVelocity().lengthSquared() < 1.0E-6;
		if (asleep && this.age % 4 != 0) {
			return;
		}

		double m = getMass();
		boolean water = this.isTouchingWater();

		Vec3d vel = this.getVelocity();
		this.setVelocity(vel.x, vel.y - (water ? 0.012 : 0.04), vel.z);

		Vec3d before = this.getVelocity();
		this.move(MovementType.SELF, before);

		if (this.horizontalCollision) {
			transferMomentum(before);
		}
		if (this.isOnGround() && before.y < -0.25) {
			onImpact(-before.y);
		}

		// Hambatan: blok ringan melayang lebih lambat, blok berat jatuh lebih cepat
		double airDrag = 1.0 - 0.02 / MathHelper.clamp(m, 0.5, 3.0);
		double friction;
		if (water) {
			friction = 0.85;
		} else if (this.isOnGround()) {
			BlockState below = this.getWorld().getBlockState(BlockPos.ofFloored(this.getX(), this.getBoundingBox().minY - 0.5, this.getZ()));
			friction = 0.5 + 0.45 * below.getBlock().getSlipperiness();
		} else {
			friction = 0.98;
		}

		Vec3d v = this.getVelocity();
		v = new Vec3d(v.x * friction, v.y * (water ? 0.85 : airDrag), v.z * friction);
		if (this.isOnGround() && v.horizontalLengthSquared() < 1.0E-5) {
			v = new Vec3d(0, v.y, 0);
		}
		this.setVelocity(v);

		if (this.isOnGround() && v.lengthSquared() < 1.0E-4) {
			this.restTicks++;
		} else {
			this.restTicks = 0;
		}

		// Jatuh ke void
		if (this.getY() < this.getWorld().getBottomY() - 16) {
			this.dropStack(new ItemStack(getBlockState().getBlock()));
			this.discard();
		}
	}

	/** Tumbukan saat mendarat: suara/partikel sesuai berat, melukai makhluk, meremukkan blok ringan di bawah. */
	private void onImpact(double speed) {
		double m = getMass();
		double energy = m * speed;
		if (energy < 1.2 || !(this.getWorld() instanceof ServerWorld serverWorld)) {
			return;
		}

		BlockState state = getBlockState();
		float volume = (float) MathHelper.clamp(energy / 5.0, 0.3, 1.6);
		float pitch = (float) MathHelper.clamp(1.3 - m * 0.07, 0.5, 1.2);
		serverWorld.playSound(null, this.getX(), this.getY(), this.getZ(), state.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, volume, pitch);

		int count = (int) MathHelper.clamp(energy * 2.0, 4, 40);
		serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
			this.getX(), this.getY() + 0.05, this.getZ(), count, 0.4, 0.05, 0.4, 0.08);

		// Makhluk yang tertimpa
		List<LivingEntity> victims = serverWorld.getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(0.05), LivingEntity::isAlive);
		for (LivingEntity victim : victims) {
			victim.damage(serverWorld.getDamageSources().fallingBlock(this), (float) Math.min(energy * 1.2, 40.0));
		}

		// Blok fisika di bawah: remuk kalau lebih ringan dari tenaga tumbukan
		List<PhysicsBlockEntity> below = serverWorld.getEntitiesByClass(PhysicsBlockEntity.class,
			this.getBoundingBox().offset(0, -0.1, 0), e -> e != this && e.isAlive());
		boolean crushed = false;
		for (PhysicsBlockEntity other : below) {
			if (energy > other.getMass() * CRUSH_FACTOR) {
				other.shatter(true);
				crushed = true;
			}
		}
		if (crushed) {
			// tembus dengan sisa tenaga
			Vec3d v = this.getVelocity();
			this.setVelocity(v.x, -speed * 0.6, v.z);
			this.setOnGround(false);
			this.restTicks = 0;
		}
	}

	/** Pemain yang berjalan menabrak block ikut mendorongnya (dibagi berat). */
	private void pushByPlayers() {
		Box probe = this.getBoundingBox().expand(0.15, -0.05, 0.15);
		List<PlayerEntity> near = this.getWorld().getEntitiesByClass(PlayerEntity.class, probe, p -> !p.isSpectator());
		Set<UUID> ids = new HashSet<>();
		for (PlayerEntity p : near) {
			ids.add(p.getUuid());
			Vec3d prev = this.seenPlayers.put(p.getUuid(), p.getPos());
			if (prev == null) {
				continue;
			}
			Vec3d move = new Vec3d(p.getX() - prev.x, 0, p.getZ() - prev.z);
			double len = move.length();
			if (len < 0.01) {
				continue;
			}
			Vec3d to = new Vec3d(this.getX() - p.getX(), 0, this.getZ() - p.getZ());
			if (to.lengthSquared() < 1.0E-6) {
				continue;
			}
			to = to.normalize();
			Vec3d dir = move.normalize();
			if (dir.dotProduct(to) > 0.4) {
				double push = Math.min(len, 0.4) * 0.9 / getMass();
				this.addVelocity(dir.x * push, 0, dir.z * push);
				this.restTicks = 0;
			}
		}
		this.seenPlayers.keySet().retainAll(ids);
	}

	/**
	 * Tumbukan dengan blok fisika lain (domino). Pakai hukum kekekalan momentum dengan
	 * kelentingan RESTITUTION: blok berat menghantam blok ringan -> yang ringan terlempar jauh,
	 * blok ringan menghantam blok berat -> memantul balik.
	 */
	private void transferMomentum(Vec3d before) {
		double speed = Math.hypot(before.x, before.z);
		if (speed < 0.05) {
			return;
		}
		Box probe = this.getBoundingBox().expand(0.06, -0.05, 0.06);
		List<PhysicsBlockEntity> others = this.getWorld().getEntitiesByClass(PhysicsBlockEntity.class, probe, e -> e != this && e.isAlive());
		if (others.isEmpty()) {
			return;
		}

		double m1 = getMass();
		for (PhysicsBlockEntity other : others) {
			double tx = other.getX() - this.getX();
			double tz = other.getZ() - this.getZ();
			// normal tumbukan = sumbu dominan (kotak sejajar sumbu)
			double nx = 0;
			double nz = 0;
			if (Math.abs(tx) > Math.abs(tz)) {
				nx = Math.signum(tx);
			} else {
				nz = Math.signum(tz);
			}
			if (nx == 0 && nz == 0) {
				continue;
			}

			double u1 = before.x * nx + before.z * nz;
			Vec3d ov = other.getVelocity();
			double u2 = ov.x * nx + ov.z * nz;
			if (u1 <= 0.02 || u1 <= u2) {
				continue;
			}

			double m2 = other.getMass();
			double total = m1 + m2;
			double v1 = (m1 * u1 + m2 * u2 - m2 * RESTITUTION * (u1 - u2)) / total;
			double v2 = (m1 * u1 + m2 * u2 + m1 * RESTITUTION * (u1 - u2)) / total;

			other.addVelocity(nx * (v2 - u2), 0, nz * (v2 - u2));
			other.restTicks = 0;

			Vec3d cur = this.getVelocity();
			double c = cur.x * nx + cur.z * nz;
			this.setVelocity(cur.x + nx * (v1 - c), cur.y, cur.z + nz * (v1 - c));
			this.restTicks = 0;
		}
	}
}
