package com.physicsconverter.registry;

import com.physicsconverter.PhysicsConverterMod;
import com.physicsconverter.screen.ConverterScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class ModScreenHandlers {
	public static final ScreenHandlerType<ConverterScreenHandler> CONVERTER = Registry.register(
		Registries.SCREEN_HANDLER,
		Identifier.of(PhysicsConverterMod.MOD_ID, "converter"),
		new ExtendedScreenHandlerType<ConverterScreenHandler, Integer>(
			(syncId, inventory, data) -> new ConverterScreenHandler(syncId, inventory),
			PacketCodecs.VAR_INT
		)
	);

	public static void init() {
	}
}
