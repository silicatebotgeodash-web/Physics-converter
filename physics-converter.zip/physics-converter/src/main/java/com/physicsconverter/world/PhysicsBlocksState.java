package com.physicsconverter.world;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.physicsconverter.item.PhysicsBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.PersistentState;
import net.minecraft.world.chunk.ChunkManager;

/**
 * Daftar posisi "blok fisika" di satu dunia. Blok-bloknya adalah block ASLI di dunia (solid),
 * dunia hanya mengingat posisi mana yang berfisika.
 *
 * Aturan kestabilan (dicek tiap 4 tick):
 * - Blok di atas block biasa yang kokoh = tertopang penuh (nilai MAX_REACH).
 * - Nilai turun 1 tiap melangkah ke samping / menggantung; naik ke atas tidak mengurangi (menara tetap kokoh).
 * - Menempel di dinding block biasa = nilai MAX_REACH - 1.
 * - Blok yang nilainya < 0 (menjulur lebih dari MAX_REACH blok dari penyangga) jatuh jadi entity.
 */
public class PhysicsBlocksState extends PersistentState {
	/** Berapa blok boleh menjulur dari penyangga sebelum jatuh. */
	public static final int MAX_REACH = 3;
	private static final int MAX_FALL_PER_PASS = 256;
	private static final String ID = "physicsconverter_blocks";

	public static final PersistentState.Type<PhysicsBlocksState> TYPE =
		new PersistentState.Type<>(PhysicsBlocksState::new, PhysicsBlocksState::fromNbt, null);

	private final Map<Long, Block> blocks = new HashMap<>();

	public static PhysicsBlocksState get(ServerWorld world) {
		return world.getPersistentStateManager().getOrCreate(TYPE, ID);
	}

	public static PhysicsBlocksState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
		PhysicsBlocksState state = new PhysicsBlocksState();
		NbtList list = nbt.getList("blocks", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound entry = list.getCompound(i);
			Identifier id = Identifier.tryParse(entry.getString("b"));
			if (id == null) {
				continue;
			}
			Block block = Registries.BLOCK.get(id);
			if (block == Blocks.AIR) {
				continue;
			}
			state.blocks.put(entry.getLong("p"), block);
		}
		return state;
	}

	@Override
	public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
		NbtList list = new NbtList();
		for (Map.Entry<Long, Block> e : this.blocks.entrySet()) {
			NbtCompound entry = new NbtCompound();
			entry.putLong("p", e.getKey());
			entry.putString("b", Registries.BLOCK.getId(e.getValue()).toString());
			list.add(entry);
		}
		nbt.put("blocks", list);
		return nbt;
	}

	public boolean contains(BlockPos pos) {
		return this.blocks.containsKey(pos.asLong());
	}

	public Block get(BlockPos pos) {
		return this.blocks.get(pos.asLong());
	}

	public void add(BlockPos pos, Block block) {
		this.blocks.put(pos.asLong(), block);
		this.markDirty();
	}

	public void remove(BlockPos pos) {
		if (this.blocks.remove(pos.asLong()) != null) {
			this.markDirty();
		}
	}

	private static boolean loaded(ChunkManager cm, BlockPos pos) {
		return cm.isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4);
	}

	private static boolean neighborsLoaded(ChunkManager cm, BlockPos pos) {
		for (Direction d : Direction.Type.HORIZONTAL) {
			if (!loaded(cm, pos.offset(d))) {
				return false;
			}
		}
		return true;
	}

	/** Penopang dari block biasa (bukan blok fisika). -1 = tidak ada. */
	private int baseSupport(ServerWorld world, BlockPos pos) {
		BlockPos below = pos.down();
		if (!contains(below) && world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP)) {
			return MAX_REACH;
		}
		int best = -1;
		for (Direction d : Direction.Type.HORIZONTAL) {
			BlockPos n = pos.offset(d);
			if (!contains(n) && world.getBlockState(n).isSideSolidFullSquare(world, n, d.getOpposite())) {
				best = MAX_REACH - 1;
			}
		}
		BlockPos above = pos.up();
		if (!contains(above) && world.getBlockState(above).isSideSolidFullSquare(world, above, Direction.DOWN)) {
			best = Math.max(best, MAX_REACH - 1);
		}
		return best;
	}

	public void tick(ServerWorld world) {
		if (this.blocks.isEmpty()) {
			return;
		}
		ChunkManager cm = world.getChunkManager();

		// 1. Buang catatan yang bloknya sudah hilang / berganti
		List<Long> stale = new ArrayList<>();
		for (Map.Entry<Long, Block> e : this.blocks.entrySet()) {
			BlockPos pos = BlockPos.fromLong(e.getKey());
			if (loaded(cm, pos) && world.getBlockState(pos).getBlock() != e.getValue()) {
				stale.add(e.getKey());
			}
		}
		for (long key : stale) {
			this.blocks.remove(key);
		}
		if (!stale.isEmpty()) {
			this.markDirty();
		}

		// 2. Hitung nilai kestabilan
		Map<Long, Integer> value = new HashMap<>();
		ArrayDeque<Long> queue = new ArrayDeque<>();
		List<Long> checked = new ArrayList<>();
		for (long key : this.blocks.keySet()) {
			BlockPos pos = BlockPos.fromLong(key);
			if (!loaded(cm, pos)) {
				continue;
			}
			if (!neighborsLoaded(cm, pos)) {
				value.put(key, MAX_REACH); // tepi chunk yang belum dimuat: anggap aman
				queue.add(key);
				continue;
			}
			checked.add(key);
			int base = baseSupport(world, pos);
			if (base >= 0) {
				value.put(key, base);
				queue.add(key);
			}
		}

		while (!queue.isEmpty()) {
			long key = queue.poll();
			int v = value.get(key);
			BlockPos p = BlockPos.fromLong(key);
			for (Direction d : Direction.values()) {
				long nk = p.offset(d).asLong();
				if (!this.blocks.containsKey(nk)) {
					continue;
				}
				int nv = v - (d == Direction.UP ? 0 : 1);
				if (nv < 0) {
					continue;
				}
				Integer cur = value.get(nk);
				if (cur == null || nv > cur) {
					value.put(nk, nv);
					queue.add(nk);
				}
			}
		}

		// 3. Yang tidak tertopang jatuh (jadi entity)
		int fallen = 0;
		for (long key : checked) {
			if (value.containsKey(key)) {
				continue;
			}
			if (fallen++ >= MAX_FALL_PER_PASS) {
				break;
			}
			PhysicsBlocks.wake(world, BlockPos.fromLong(key), 0.0, 0.0);
		}
	}
}
