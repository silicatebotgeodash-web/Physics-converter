package com.physicsconverter.entity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Block berfisika: jatuh karena gravitasi, bertabrakan dengan block dunia dan
 * block fisika lain (jadi bisa ditumpuk), bisa didorong pemain, ditendang
 * (klik kiri) atau dihancurkan (sneak + klik kiri).
 * Kalau block di bawah dihancurkan, block di atasnya otomatis jatuh/terpisah.
 */
public class PhysicsBlockEntity extends Entity {
	private static final TrackedData<BlockState> BLOCK_STATE =
		DataTracker.registerData(PhysicsBlockEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);

	private final Map<UUID, Vec3d> seenPlayers = new HashMap<>();
	private int restTicks = 0;

	public PhysicsBlockEntity(EntityType<? extends PhysicsBlockEntity> type, World world) {
		super(type, world);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(BLOCK_STATE, Blocks.STONE.getDefaultState());
	}

	public BlockState getBlockState() {
		return this.dataTracker.get(BLOCK_STATE);
	}

	public void setBlockState(BlockState state) {
		this.dataTracker.set(BLOCK_STATE, state);
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		Identifier id = Identifier.tryParse(nbt.getString("block"));
		Block block = id == null ? Blocks.STONE : Registries.BLOCK.get(id);
		if (block == Blocks.AIR) {
			block = Blocks.STONE;
		}
		setBlockState(block.getDefaultState());
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putString("block", Registries.BLOCK.getId(getBlockState().getBlock()).toString());
	}

	@Override
	public boolean canHit() {
		return !this.isRemoved();
	}

	@Override
	public boolean isCollidable() {
		return true;
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.getWorld().isClient || this.isRemoved()) {
			return false;
		}
		if (!(source.getAttacker() instanceof PlayerEntity player)) {
			return false;
		}

		BlockState state = getBlockState();

		// Sneak + klik kiri = hancurkan
		if (player.isSneaking()) {
			this.getWorld().playSound(null, this.getBlockPos(), state.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);
			if (this.getWorld() instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
					this.getX(), this.getY() + 0.5, this.getZ(), 20, 0.3, 0.3, 0.3, 0.05);
			}
			if (!player.isCreative()) {
				this.dropStack(new ItemStack(state.getBlock()));
			}
			this.discard();
			return true;
		}

		// Klik kiri biasa = tendang ke arah pandangan
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d dir = new Vec3d(look.x, 0, look.z);
		if (dir.lengthSquared() > 1.0E-4) {
			dir = dir.normalize();
		} else {
			dir = Vec3d.ZERO;
		}
		this.addVelocity(dir.x * 0.45, 0.22, dir.z * 0.45);
		this.getWorld().playSound(null, this.getBlockPos(), state.getSoundGroup().getHitSound(), SoundCategory.BLOCKS, 1.0f, 0.9f);
		this.restTicks = 0;
		return true;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			return;
		}

		pushByPlayers();

		// Tidur hemat CPU kalau sudah diam di tanah (tetap cek tiap 4 tick kalau penyangga hilang)
		if (this.restTicks > 10 && this.getVelocity().lengthSquared() < 1.0E-6 && this.age % 4 != 0) {
			return;
		}

		boolean water = this.isTouchingWater();
		Vec3d vel = this.getVelocity();
		this.setVelocity(vel.x, vel.y - (water ? 0.012 : 0.04), vel.z);

		Vec3d before = this.getVelocity();
		this.move(MovementType.SELF, before);

		if (this.horizontalCollision) {
			transferMomentum(before);
		}

		Vec3d v = this.getVelocity();
		double horizontalDrag = water ? 0.85 : (this.isOnGround() ? 0.55 : 0.98);
		double verticalDrag = water ? 0.85 : 0.98;
		v = new Vec3d(v.x * horizontalDrag, v.y * verticalDrag, v.z * horizontalDrag);

		if (this.isOnGround() && v.horizontalLengthSquared() < 1.0E-5) {
			v = new Vec3d(0, v.y, 0);
		}
		this.setVelocity(v);

		if (this.isOnGround() && v.lengthSquared() < 1.0E-4) {
			this.restTicks++;
		} else {
			this.restTicks = 0;
		}

		// Jatuh ke void
		if (this.getY() < this.getWorld().getBottomY() - 16) {
			this.dropStack(new ItemStack(getBlockState().getBlock()));
			this.discard();
		}
	}

	/** Pemain yang berjalan menabrak block akan mendorongnya. */
	private void pushByPlayers() {
		Box probe = this.getBoundingBox().expand(0.15, -0.05, 0.15);
		List<PlayerEntity> near = this.getWorld().getEntitiesByClass(PlayerEntity.class, probe, p -> !p.isSpectator());
		Set<UUID> ids = new HashSet<>();
		for (PlayerEntity p : near) {
			ids.add(p.getUuid());
			Vec3d prev = this.seenPlayers.put(p.getUuid(), p.getPos());
			if (prev == null) {
				continue;
			}
			Vec3d move = new Vec3d(p.getX() - prev.x, 0, p.getZ() - prev.z);
			double len = move.length();
			if (len < 0.01) {
				continue;
			}
			Vec3d to = new Vec3d(this.getX() - p.getX(), 0, this.getZ() - p.getZ());
			if (to.lengthSquared() < 1.0E-6) {
				continue;
			}
			to = to.normalize();
			Vec3d dir = move.normalize();
			if (dir.dotProduct(to) > 0.4) {
				double push = Math.min(len, 0.4) * 0.9;
				this.addVelocity(dir.x * push, 0, dir.z * push);
				this.restTicks = 0;
			}
		}
		this.seenPlayers.keySet().retainAll(ids);
	}

	/** Block yang meluncur lalu menabrak block fisika lain akan mendorongnya (efek domino). */
	private void transferMomentum(Vec3d before) {
		double speed = Math.sqrt(before.x * before.x + before.z * before.z);
		if (speed < 0.08) {
			return;
		}
		Vec3d dir = new Vec3d(before.x, 0, before.z).normalize();
		Box probe = this.getBoundingBox().expand(0.08, -0.05, 0.08);
		List<PhysicsBlockEntity> others = this.getWorld().getEntitiesByClass(PhysicsBlockEntity.class, probe, e -> e != this);
		for (PhysicsBlockEntity other : others) {
			Vec3d to = new Vec3d(other.getX() - this.getX(), 0, other.getZ() - this.getZ());
			if (to.lengthSquared() < 1.0E-6) {
				continue;
			}
			double dot = dir.dotProduct(to.normalize());
			if (dot < 0.5) {
				continue;
			}
			other.addVelocity(dir.x * speed * 0.8 * dot, 0, dir.z * speed * 0.8 * dot);
			other.restTicks = 0;
			Vec3d mine = this.getVelocity();
			this.setVelocity(mine.x * 0.2, mine.y, mine.z * 0.2);
		}
	}
}
