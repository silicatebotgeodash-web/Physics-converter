package com.physicsconverter.network;

import com.physicsconverter.PhysicsConverterMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: pemain sedang berjalan menabrak sesuatu ke arah dir (0 = +X, 1 = -X, 2 = +Z, 3 = -Z). */
public record PushPayload(int dir) implements CustomPayload {
	public static final CustomPayload.Id<PushPayload> ID =
		new CustomPayload.Id<>(Identifier.of(PhysicsConverterMod.MOD_ID, "push"));
	public static final PacketCodec<ByteBuf, PushPayload> CODEC =
		PacketCodecs.VAR_INT.xmap(PushPayload::new, PushPayload::dir);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
