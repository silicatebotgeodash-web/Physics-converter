package com.physicsconverter.screen;

import com.physicsconverter.item.PhysicsBlockItem;
import com.physicsconverter.registry.ModScreenHandlers;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/** UI 1 slot: block yang masuk langsung berubah jadi Physics Block. */
public class ConverterScreenHandler extends ScreenHandler {
	private final SimpleInventory inventory = new SimpleInventory(1);
	private final boolean clientSide;

	public ConverterScreenHandler(int syncId, PlayerInventory playerInventory) {
		super(ModScreenHandlers.CONVERTER, syncId);
		this.clientSide = playerInventory.player.getWorld().isClient;

		this.inventory.addListener(this::convert);

		this.addSlot(new Slot(this.inventory, 0, 80, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return PhysicsBlockItem.isConvertible(stack);
			}
		});

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	private void convert(Inventory changed) {
		if (this.clientSide) {
			return;
		}
		ItemStack stack = this.inventory.getStack(0);
		if (PhysicsBlockItem.isConvertible(stack)) {
			Block block = ((BlockItem) stack.getItem()).getBlock();
			this.inventory.setStack(0, PhysicsBlockItem.of(block, stack.getCount()));
		}
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int slotIndex) {
		ItemStack result = ItemStack.EMPTY;
		Slot slot = this.slots.get(slotIndex);
		if (slot != null && slot.hasStack()) {
			ItemStack original = slot.getStack();
			result = original.copy();
			if (slotIndex == 0) {
				if (!this.insertItem(original, 1, 37, true)) {
					return ItemStack.EMPTY;
				}
			} else if (!this.insertItem(original, 0, 1, false)) {
				return ItemStack.EMPTY;
			}
			if (original.isEmpty()) {
				slot.setStack(ItemStack.EMPTY);
			} else {
				slot.markDirty();
			}
		}
		return result;
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return true;
	}

	@Override
	public void onClosed(PlayerEntity player) {
		super.onClosed(player);
		this.dropInventory(player, this.inventory);
	}
}
