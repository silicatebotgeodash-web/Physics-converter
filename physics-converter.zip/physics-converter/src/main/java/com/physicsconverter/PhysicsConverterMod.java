package com.physicsconverter;

import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModItems;
import com.physicsconverter.registry.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.ActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;

public class PhysicsConverterMod implements ModInitializer {
	public static final String MOD_ID = "physicsconverter";

	@Override
	public void onInitialize() {
		ModEntities.init();
		ModItems.init();
		ModScreenHandlers.init();

		// Item blok fisik (blok asli yang sudah ditandai) -> saat diletakkan jadi entity berfisika
		UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
			ItemStack stack = player.getStackInHand(hand);
			if (player.isSpectator() || !PhysicsBlocks.isPhysics(stack)) {
				return ActionResult.PASS;
			}
			if (world.isClient) {
				return ActionResult.SUCCESS;
			}

			BlockPos clicked = hit.getBlockPos();
			BlockPos target = world.getBlockState(clicked).isReplaceable() ? clicked : clicked.offset(hit.getSide());
			Block block = PhysicsBlocks.getBlock(stack);
			if (!PhysicsBlocks.spawn(world, block, target.getX() + 0.5, target.getY(), target.getZ() + 0.5)) {
				return ActionResult.FAIL;
			}

			world.playSound(null, target, block.getDefaultState().getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.8f);
			if (!player.isCreative()) {
				stack.decrement(1);
			}
			return ActionResult.SUCCESS;
		});

		// Menumpuk: bidik blok fisik lain (bukan block biasa) lalu klik kanan -> blok fisik baru ditaruh di sisi yang dibidik
		UseItemCallback.EVENT.register((player, world, hand) -> {
			ItemStack stack = player.getStackInHand(hand);
			if (player.isSpectator() || !PhysicsBlocks.isPhysics(stack)) {
				return TypedActionResult.pass(stack);
			}
			return PhysicsBlocks.placeOnPhysicsBlock(world, player, stack);
		});
	}
}
