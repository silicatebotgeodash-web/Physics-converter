package com.physicsconverter.registry;

import com.physicsconverter.PhysicsConverterMod;
import com.physicsconverter.item.PhysicsBlockItem;
import com.physicsconverter.item.PhysicsConverterItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
	public static final Item PHYSICS_CONVERTER = Registry.register(
		Registries.ITEM,
		Identifier.of(PhysicsConverterMod.MOD_ID, "physics_converter"),
		new PhysicsConverterItem(new Item.Settings().maxCount(1))
	);

	public static final Item PHYSICS_BLOCK = Registry.register(
		Registries.ITEM,
		Identifier.of(PhysicsConverterMod.MOD_ID, "physics_block"),
		new PhysicsBlockItem(new Item.Settings())
	);

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(PHYSICS_CONVERTER));
	}
}
