package com.physicsconverter.screen;

import com.physicsconverter.item.PhysicsBlocks;
import com.physicsconverter.registry.ModScreenHandlers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/**
 * UI 2 slot: slot kiri = input (block biasa), slot kanan = hasil (Physics Block).
 * Hasil muncul otomatis; mengambilnya memakai block di slot input.
 */
public class ConverterScreenHandler extends ScreenHandler {
	public static final int INPUT_SLOT = 0;
	public static final int OUTPUT_SLOT = 1;
	private static final int PLAYER_START = 2;
	private static final int PLAYER_END = 38; // eksklusif: 27 inventory + 9 hotbar
	private static final int HOTBAR_START = 29;

	private final SimpleInventory input = new SimpleInventory(1);
	private final SimpleInventory output = new SimpleInventory(1);
	private final boolean clientSide;

	public ConverterScreenHandler(int syncId, PlayerInventory playerInventory) {
		super(ModScreenHandlers.CONVERTER, syncId);
		this.clientSide = playerInventory.player.getWorld().isClient;

		this.input.addListener(this::onInputChanged);

		this.addSlot(new Slot(this.input, 0, 50, 35) {
			@Override
			public boolean canInsert(ItemStack stack) {
				return PhysicsBlocks.isConvertible(stack);
			}
		});
		this.addSlot(new OutputSlot(this.output, 0, 110, 35));

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	/** Isi slot hasil dari slot input (hanya dijalankan di server; client menerima lewat sinkronisasi). */
	private void onInputChanged(Inventory changed) {
		if (this.clientSide) {
			return;
		}
		ItemStack in = this.input.getStack(0);
		if (PhysicsBlocks.isConvertible(in)) {
			this.output.setStack(0, PhysicsBlocks.convert(in));
		} else {
			this.output.setStack(0, ItemStack.EMPTY);
		}
	}

	public ItemStack getOutputStack() {
		return this.slots.get(OUTPUT_SLOT).getStack();
	}

	private class OutputSlot extends Slot {
		OutputSlot(Inventory inventory, int index, int x, int y) {
			super(inventory, index, x, y);
		}

		@Override
		public boolean canInsert(ItemStack stack) {
			return false;
		}

		@Override
		public void onTakeItem(PlayerEntity player, ItemStack stack) {
			// Ambil hasil = pakai block di slot input sebanyak yang diambil
			ConverterScreenHandler.this.input.removeStack(0, stack.getCount());
		}
	}

	@Override
	public ItemStack quickMove(PlayerEntity player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasStack()) {
			return ItemStack.EMPTY;
		}
		ItemStack original = slot.getStack();
		ItemStack copy = original.copy();

		if (index == OUTPUT_SLOT) {
			int before = original.getCount();
			if (!this.insertItem(original, PLAYER_START, PLAYER_END, true)) {
				return ItemStack.EMPTY;
			}
			int moved = before - original.getCount();
			if (moved > 0) {
				this.input.removeStack(0, moved); // otomatis mengisi ulang slot hasil
			}
			return copy;
		}

		if (index == INPUT_SLOT) {
			if (!this.insertItem(original, PLAYER_START, PLAYER_END, true)) {
				return ItemStack.EMPTY;
			}
		} else if (PhysicsBlocks.isConvertible(original)) {
			if (!this.insertItem(original, INPUT_SLOT, INPUT_SLOT + 1, false)) {
				return ItemStack.EMPTY;
			}
		} else if (index < HOTBAR_START) {
			if (!this.insertItem(original, HOTBAR_START, PLAYER_END, false)) {
				return ItemStack.EMPTY;
			}
		} else if (!this.insertItem(original, PLAYER_START, HOTBAR_START, false)) {
			return ItemStack.EMPTY;
		}

		if (original.isEmpty()) {
			slot.setStack(ItemStack.EMPTY);
		} else {
			slot.markDirty();
		}
		return copy;
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return true;
	}

	@Override
	public void onClosed(PlayerEntity player) {
		super.onClosed(player);
		// Hanya input yang dikembalikan; hasil cuma turunan dari input
		this.dropInventory(player, this.input);
	}
}
