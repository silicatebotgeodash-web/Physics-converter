package com.physicsconverter;

import com.physicsconverter.registry.ModEntities;
import com.physicsconverter.registry.ModItems;
import com.physicsconverter.registry.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;

public class PhysicsConverterMod implements ModInitializer {
	public static final String MOD_ID = "physicsconverter";

	@Override
	public void onInitialize() {
		ModEntities.init();
		ModItems.init();
		ModScreenHandlers.init();
	}
}
