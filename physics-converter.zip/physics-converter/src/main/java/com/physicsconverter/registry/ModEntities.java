package com.physicsconverter.registry;

import com.physicsconverter.PhysicsConverterMod;
import com.physicsconverter.entity.PhysicsBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
	public static final EntityType<PhysicsBlockEntity> PHYSICS_BLOCK = Registry.register(
		Registries.ENTITY_TYPE,
		Identifier.of(PhysicsConverterMod.MOD_ID, "physics_block"),
		FabricEntityTypeBuilder.<PhysicsBlockEntity>create(SpawnGroup.MISC, PhysicsBlockEntity::new)
			.dimensions(EntityDimensions.fixed(0.98f, 0.98f))
			.trackRangeBlocks(64)
			.trackedUpdateRate(1)
			.forceTrackedVelocityUpdates(true)
			.fireImmune()
			.build()
	);

	public static void init() {
	}
}
