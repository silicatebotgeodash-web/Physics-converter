package com.physicsconverter.entity;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EmptyBlockView;

/**
 * Berat tiap blok. Dasarnya kekerasan (hardness) blok, ditambah daftar khusus
 * untuk blok yang di dunia nyata padat/berat (netherite, emas, besi, dst).
 * Dipakai di server (fisika) dan client (tooltip / UI), hasilnya sama.
 */
public final class PhysicsMass {
	private static final Map<Block, Double> OVERRIDES = new HashMap<>();

	static {
		OVERRIDES.put(Blocks.NETHERITE_BLOCK, 14.0);
		OVERRIDES.put(Blocks.ANCIENT_DEBRIS, 12.0);
		OVERRIDES.put(Blocks.GOLD_BLOCK, 11.0);
		OVERRIDES.put(Blocks.IRON_BLOCK, 9.0);
		OVERRIDES.put(Blocks.ANVIL, 9.0);
		OVERRIDES.put(Blocks.OBSIDIAN, 9.0);
		OVERRIDES.put(Blocks.CRYING_OBSIDIAN, 9.0);
		OVERRIDES.put(Blocks.COPPER_BLOCK, 8.0);
		OVERRIDES.put(Blocks.DIAMOND_BLOCK, 6.0);
		OVERRIDES.put(Blocks.EMERALD_BLOCK, 6.0);
		OVERRIDES.put(Blocks.LAPIS_BLOCK, 4.5);
		OVERRIDES.put(Blocks.REDSTONE_BLOCK, 4.0);
		OVERRIDES.put(Blocks.COAL_BLOCK, 3.5);
		OVERRIDES.put(Blocks.BEDROCK, 15.0);
	}

	private PhysicsMass() {
	}

	public static double of(BlockState state) {
		Double fixed = OVERRIDES.get(state.getBlock());
		if (fixed != null) {
			return fixed;
		}
		float hardness = state.getHardness(EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
		if (hardness < 0) {
			return 15.0;
		}
		// tanah/pasir ~1.3, batu ~1.9, wol ~1.5, TNT/kaca/daun ~0.5-0.7
		return 0.5 + Math.sqrt(Math.min(hardness, 50.0f)) * 1.1;
	}

	/** Kecepatan geser (blok/tick) saat didorong pemain yang berjalan: blok ringan ikut kecepatan jalan, blok berat merayap. */
	public static double pushSpeed(double mass) {
		return Math.min(0.22, 0.28 / Math.pow(mass, 0.7));
	}

	public static String format(double mass) {
		return String.format(Locale.ROOT, "%.1f", mass);
	}
}
