package com.physicsconverter.item;

import com.physicsconverter.screen.ConverterScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PhysicsConverterItem extends Item {
	public PhysicsConverterItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (!world.isClient) {
			player.openHandledScreen(new ExtendedScreenHandlerFactory<Integer>() {
				@Override
				public Integer getScreenOpeningData(ServerPlayerEntity serverPlayer) {
					return 0;
				}

				@Override
				public Text getDisplayName() {
					return Text.translatable("gui.physicsconverter.converter");
				}

				@Override
				public ScreenHandler createMenu(int syncId, PlayerInventory inventory, PlayerEntity p) {
					return new ConverterScreenHandler(syncId, inventory);
				}
			});
		}
		return TypedActionResult.success(stack, world.isClient);
	}
}
