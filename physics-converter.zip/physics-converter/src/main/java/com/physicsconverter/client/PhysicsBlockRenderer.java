package com.physicsconverter.client;

import com.physicsconverter.entity.PhysicsBlockEntity;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class PhysicsBlockRenderer extends EntityRenderer<PhysicsBlockEntity> {
	private static final Identifier BLOCK_ATLAS = Identifier.ofVanilla("textures/atlas/blocks.png");

	public PhysicsBlockRenderer(EntityRendererFactory.Context context) {
		super(context);
		this.shadowRadius = 0.4f;
	}

	@Override
	public void render(PhysicsBlockEntity entity, float yaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider vertexConsumers, int light) {
		BlockState state = entity.getBlockState();
		if (state.getRenderType() == BlockRenderType.MODEL) {
			matrices.push();
			// Hitbox 0.98, jadi digambar sedikit mengecil biar pas dan tidak z-fighting
			matrices.scale(0.98f, 0.98f, 0.98f);
			matrices.translate(-0.5, 0.0, -0.5);
			MinecraftClient.getInstance().getBlockRenderManager()
				.renderBlockAsEntity(state, matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
			matrices.pop();
		}
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}

	@Override
	public Identifier getTexture(PhysicsBlockEntity entity) {
		return BLOCK_ATLAS;
	}
}
